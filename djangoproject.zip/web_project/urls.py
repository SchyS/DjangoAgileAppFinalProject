# Import necessary modules
from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.staticfiles.urls import staticfiles_urlpatterns

# Import views from the appropriate apps
from users.views import home, login_page, register_page, logout_view, profile_view
from users.views import create_event, update_event, delete_event  # Import from the events app

# Define URL patterns
urlpatterns = [
    path("admin/", admin.site.urls),  # Admin panel
    path('home/', home, name="home"),  # Home page
    path('login/', login_page, name='login_page'),  # Login page
    path('register/', register_page, name='register'),  # Registration page
    path('logout/', logout_view, name='logout'),  # Logout page
    path('profile/', profile_view, name='profile'),  # Profile page

    # Event CRUD URLs (Moved to events app)
    path('event/create/', create_event, name='create_event'),
    path('event/update/<int:event_id>/', update_event, name='update_event'),
    path('event/delete/<int:event_id>/', delete_event, name='delete_event'),
]

# Serve media files if DEBUG is True (development mode)
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

# Serve static files
urlpatterns += staticfiles_urlpatterns()
